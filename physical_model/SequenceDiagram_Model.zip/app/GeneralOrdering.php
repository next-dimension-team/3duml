<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GeneralOrdering extends Model {

	protected $table = 'general_orderings';
	public $timestamps = true;

}