<?php

namespace App\Models;

class Lifeline extends Eloquent {

	protected $table = 'lifelines';
	public $timestamps = true;

	public function executionOccurrenceSpecification()
	{
		return $this->hasMany('ExecutionOccurrenceSpecification');
	}

	public function interaction()
	{
		return $this->belongsTo('Interaction');
	}

	public function stateInvariant()
	{
		return $this->hasMany('StateInvariant');
	}

	public function messageOccurrenceSpecification()
	{
		return $this->hasMany('MessageOccurrenceSpecifications');
	}

	public function lifelineCombinedFragment()
	{
		return $this->hasMany('LifelineCombinedFragments');
	}

	public function lifelineInteractionOperand()
	{
		return $this->hasMany('LifelineInteractionOperand');
	}

}