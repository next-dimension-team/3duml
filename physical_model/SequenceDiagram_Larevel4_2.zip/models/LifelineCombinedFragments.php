<?php

namespace App\Models;

class LifelineCombinedFragments extends Eloquent {

	protected $table = 'lifelines_combined_fragments';
	public $timestamps = true;

	public function lifeline()
	{
		return $this->belongsTo('Lifeline');
	}

	public function combinedFragment()
	{
		return $this->belongsTo('CombinedFragment');
	}

}