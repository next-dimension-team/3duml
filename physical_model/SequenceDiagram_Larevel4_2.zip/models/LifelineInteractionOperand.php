<?php

namespace App\Models;

class LifelineInteractionOperand extends Eloquent {

	protected $table = 'lifelines_interaction_operands';
	public $timestamps = true;

	public function lifeline()
	{
		return $this->belongsTo('Lifeline');
	}

	public function interactionOperand()
	{
		return $this->belongsTo('InteractionOperand');
	}

}