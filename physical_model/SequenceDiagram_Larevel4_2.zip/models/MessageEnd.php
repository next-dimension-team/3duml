<?php

namespace App\Models;

class MessageEnd extends Eloquent {

	protected $table = 'message_ends';
	public $timestamps = true;

	public function message()
	{
		return $this->belongsTo('Message');
	}

}