<?php

namespace App\Models;

class InteractionOperand extends Eloquent {

	protected $table = 'interaction_operands';
	public $timestamps = true;

	public function lifelineInteractionOperand()
	{
		return $this->hasMany('LifelineInteractionOperand');
	}

	public function combinedFragment()
	{
		return $this->belongsTo('CombinedFragment');
	}

}