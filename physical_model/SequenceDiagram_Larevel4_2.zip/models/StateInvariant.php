<?php

namespace App\Models;

class StateInvariant extends Eloquent {

	protected $table = 'state_invariants';
	public $timestamps = true;

	public function lifeline()
	{
		return $this->belongsTo('Lifeline');
	}

}