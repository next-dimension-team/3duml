<?php

namespace App\Models;

class CombinedFragment extends Eloquent {

	protected $table = 'combined_fragments';
	public $timestamps = true;

	public function lifelineCombinedFragment()
	{
		return $this->hasMany('LifelineCombinedFragments');
	}

	public function interactionOperand()
	{
		return $this->hasMany('InteractionOperand');
	}

	public function interaction()
	{
		return $this->belongsTo('Interaction');
	}

}