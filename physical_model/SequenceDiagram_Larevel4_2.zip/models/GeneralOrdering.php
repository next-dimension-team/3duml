<?php

namespace App\Models;

class GeneralOrdering extends Eloquent {

	protected $table = 'general_orderings';
	public $timestamps = true;

}