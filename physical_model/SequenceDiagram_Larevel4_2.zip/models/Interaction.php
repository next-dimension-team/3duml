<?php

namespace App\Models;

class Interaction extends Eloquent {

	protected $table = 'interactions';
	public $timestamps = true;

	public function lifeline()
	{
		return $this->hasMany('Lifeline');
	}

	public function message()
	{
		return $this->hasMany('Message');
	}

	public function combinedFragment()
	{
		return $this->hasMany('CombinedFragment');
	}

}