<?php

namespace App\Models;

class MessageOccurrenceSpecifications extends Eloquent {

	protected $table = 'message_occurrence_specifications';
	public $timestamps = true;

	public function lifelines()
	{
		return $this->belongsTo('Lifeline');
	}

}