<?php

namespace App\Models;

class Message extends Eloquent {

	protected $table = 'messages';
	public $timestamps = true;

	public function interaction()
	{
		return $this->belongsTo('Interaction');
	}

	public function messageEnd()
	{
		return $this->hasOne('MessageEnd');
	}

}